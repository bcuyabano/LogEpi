#' Download latest Covid-19 data from JHU database
#'
#' This function will load the latest Covid-19 data for the historical number of confirmed cases, deaths, and recovery. Both global and United States data will be downloaded. The data is provided by Johns Hopkins University (https://systems.jhu.edu/research/public-health/ncov/), available at repository https://github.com/CSSEGISandData/COVID-19
#'
#' @param folder The folder in which the downloaded data will be saved.
#' @param filename The standard filename to save the data,
#' @return
#' \describe{
#' \item{countries}{A list of the countries with records in the database.}
#' \item{US_states}{A list of the states/provinces in the US with records in the database.}
#' }
#' @examples load_JH_db("Desktop","covid19JHU")
#' @export
load_JH_db <- function(folder,filename)
{
  for(data.type in c("confirmed","deaths","recovered"))
  {
    for(loc in c("US","global"))
    {
      info.url <- paste0("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_",data.type,"_",loc,".csv")
      try(download.file(info.url,paste0(folder,"/",filename,"_",data.type,"_",loc,".csv")),silent=TRUE)
    }
  }
  for(data.type in c("confirmed","deaths","recovered"))
  {
    for(loc in c("US","global"))
    {
      info.url <- paste0("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_",data.type,"_",loc,".csv")
      try(download.file(info.url,paste0(folder,"/",filename,"_",data.type,"_",loc,".csv")),silent=TRUE)
    }
  }
  # get list of countries
  loc <- "global"
  data.type <- "confirmed"
  tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=TRUE)
  names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=FALSE,nrows=1))))
  countries <- sort(unique(tmp[,"Country/Region"]))
  # get list of US states
  loc <- "US"
  data.type <- "confirmed"
  tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=TRUE)
  names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=FALSE,nrows=1))))
  US_states <- sort(unique(tmp[,"Province_State"]))
  return(list(countries=as.character(countries),US_states=as.character(US_states)))
}

#' Extract Covid-19 data from a specific location
#'
#' This function will extract the Covid-19 data from a specific location, out of the downloaded databases
#'
#' @param location The name of the location of interest. If data="global", location is a country. If data="US", location is a state.
#' @param data The data base where the location is at. Either location="global" or location="US".
#' @param folder The folder in which the downloaded data was saved with load_JH_db().
#' @param filename The standard filename with which the data was saved with load_JH_db().
#' @return A list containing the data on confirmed cases, deaths, and recovered individuals. Data for recovered individuals is currently not available for States in the US data.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples extract_covid19_data("Michigan","US","Desktop","covid19JHU")
#' @seealso \code{\link{load_JH_db}}
#' @export
extract_covid19_data <- function(location,data,folder,filename)
{
  # dates as strings
  first.record <- as.Date("2020-01-22")
  ndays <- as.numeric(today()-first.record)
  all.days <- first.record + seq(0,ndays,1)
  dates <- paste(month(all.days),day(all.days),substr(as.character(year(all.days)),3,4),sep="/")
  # build dataset
  if(data == "global")
  {
    data.out <- list(confirmed=NULL,deaths=NULL,recovered=NULL)
    for(data.type in names(data.out))
    {
      tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=TRUE)
      names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=FALSE,nrows=1))))
      data.out[[data.type]] <- tmp[tmp[,"Country/Region"] == location,c("Province/State",names(tmp)[names(tmp) %in% dates])]
      rownames(data.out[[data.type]]) <- 1:nrow(data.out[[data.type]])
    }
  } else if(data == "US")
  {
    data.out <- list(confirmed=NULL,deaths=NULL)
    for(data.type in names(data.out))
    {
      tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=TRUE)
      names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=FALSE,nrows=1))))
      data.out[[data.type]] <- tmp[tmp[,"Province_State"] == location,c("Admin2",names(tmp)[names(tmp) %in% dates])]
      rownames(data.out[[data.type]]) <- 1:nrow(data.out[[data.type]])
    }
  }
  return(data.out)
}

#' Create epidemic table
#'
#' This function will structure the extracted Covid-19 data from a location. A specific province (or county, state, administrative region, etc) can be determined.
#'
#' @param data The dataset extracted with extract_covid19_data().
#' @param specific A specific province (or county, state, administrative region, etc). Default is specific=NULL, meaning that all areas in the location will be considered.
#' @param daily Return daily notifications instead of cumulative? Default daily=FALSE.
#' @return A data frame with the structured Covid-19 data at the location of interest.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples mkEpiTable(dataCovid,"China")
#' @examples mkEpiTable(dataCovid,"China",specific="Hubei")
#' @examples mkEpiTable(dataCovid,"China",specific=c("Hubei","Guangdong"))
#' @seealso \code{\link{load_JH_db}}
#' @seealso \code{\link{extract_covid19_data}}
#' @export
mkEpiTable <- function(data,specific=NULL,daily=FALSE)
{
  tmp <- unlist(strsplit(names(data[[1]])[2],"/"))
  dates <- as.Date(paste0(tmp[1],"-",tmp[2],"-20",tmp[3]),format="%m-%d-%Y") + 0:(ncol(data[[1]])-2)
  tmp <- data.frame(date=dates,confirmed=rep(NA,length(dates)),deaths=rep(NA,length(dates)),recovered=rep(NA,length(dates)))
  for(i in 1:length(data))
  {
    if(is.null(specific))
    {
      tmp[,names(data)[i]] <- as.numeric(apply(data[[i]][,-1],2,sum))
    } else
    {
      if(length(specific) == 1)
      {
        tmp[,names(data)[i]] <- as.numeric(data[[i]][data[[i]][,1] == specific,-1])
      } else tmp[,names(data)[i]] <- as.numeric(apply(data[[i]][data[[i]][,1] %in% specific,-1],2,sum))
    }
  }
  if(!any(is.na(tmp$recovered)))
  {
    tmp$active <- tmp$confirmed - tmp$deaths - tmp$recovered
  } else tmp$active <- rep(NA,nrow(tmp))
  if(daily)
  {
    tmp$confirmed <- c(tmp$confirmed[1],tmp$confirmed[-1]-tmp$confirmed[-nrow(tmp)])
    tmp$deaths <- c(tmp$deaths[1],tmp$deaths[-1]-tmp$deaths[-nrow(tmp)])
    if(!any(is.na(tmp$recovered)))
    {
      tmp$recovered <- c(tmp$recovered[1],tmp$recovered[-1]-tmp$recovered[-nrow(tmp)])
    }
  }
  return(tmp)
}

#' Create epidemic curves
#'
#' This function will estimate the curves for the Covid-19 epidemic.
#'
#' @param data The epidemic table, in the format of a data frame, with columns: date, confirmed, deaths, recovered.
#' @param project An integer indicating how many days ahead should be projected. Default project=NULL indicates that no projection will be done.
#' @param rates A list of rates to project confirmed cases and deaths. If no rates are given, the average rate of the last five days in the data will be used.
#' @param plot.curves Should the curves be plotted?
#' @param plot.title A title for the plot. Recomended to use the location which the analyses refers to.
#' @param return.data Should the calculated values be returned?
#' @return
#' \describe{
#' \item{par}{The estimated parameters for the logistic curves.}
#' \item{day1}{The dates considered as x=1 to fit the logistic curves.}
#' \item{key_dates}{The important dates of the critical period.}
#' \item{fit}{The fitted values.}
#' \item{res}{The residuals of the model.}
#' \item{rates}{The epidemic rates.}
#' \item{projection}{The values projected.}
#' \item{rates_proj}{The epidemic rates used for the projection.}
#' }
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples dataChina <- mkEpiTable(dataCovid,"China")
#' @examples mkEpiCurves(dataChina)
#' @examples #---------------------------------#
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("New Zealand","global","Desktop","covid19JHU")
#' @examples dataNZ <- mkEpiTable(dataCovid,"New Zealand")
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand")
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7)
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(confirmed=1.2))
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(deaths=1.1))
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(confirmed=1.2,deaths=1.1))
#' @seealso \code{\link{load_JH_db}}
#' @seealso \code{\link{extract_covid19_data}}
#' @seealso \code{\link{mkEpiTable}}
#' @export
mkEpiCurves <- function(data,project=NULL,rates=NULL,plot.curves=TRUE,plot.title="",return.data=TRUE)
{
  # cut data to contain only records with confirmed > 0
  data <- data[min(which(data$confirmed >= 1)):nrow(data),]
  # calculate rates
  rates.obs <- data.frame(date=data$date,confirmed=rep(0,nrow(data)),deaths=rep(0,nrow(data)),recovered=rep(0,nrow(data)))
  tmp <- c(0,data$confirmed[-1]/data$confirmed[-nrow(data)])
  rates.obs$confirmed <- c(rep(0,min(which(data$confirmed > 0))),tmp[(min(which(data$confirmed > 0))+1):nrow(data)])
  tmp <- c(0,data$deaths[-1]/data$deaths[-nrow(data)])
  rates.obs$deaths <- c(rep(0,min(which(data$deaths > 0))),tmp[(min(which(data$deaths > 0))+1):nrow(data)])
  if(!any(is.na(data[,"recovered"])))
  {
    tmp <- c(0,data$recovered[-1]/data$recovered[-nrow(data)])
    rates.obs$recovered <- c(rep(0,min(which(data$recovered > 0))),tmp[(min(which(data$recovered > 0))+1):nrow(data)])
  }
  #----------------#
  # add projection #
  #----------------#
  if(!is.null(project))
  {
    if(is.null(rates))
    {
      rates <- list(confirmed=mean(rev(rates.obs$confirmed)[1:5]),deaths=mean(rev(rates.obs$deaths)[1:5]))
    } else
    {
      if(!any(names(rates) == "confirmed"))
      {
        rates$confirmed=max(c(1,mean(rev(rates.obs$confirmed)[1:5])))
      }
      if(!any(names(rates) == "deaths"))
      {
        rates$deaths=max(c(1,mean(rev(rates.obs$deaths)[1:5])))
      }
    }
    data_project <- data.frame(date=data$date[nrow(data)]+1:project,confirmed=rep(NA,project),deaths=rep(NA,project),recovered=rep(max(data$recovered),project))
    data_project$confirmed <- round(data$confirmed[nrow(data)]*rates$confirmed^(1:project))
    data_project$deaths <- round(data$deaths[nrow(data)]*rates$deaths^(1:project))
    if(!any(is.na(data[,"recovered"])))
    {
      data_project$active <- data_project$confirmed - data_project$deaths - data_project$recovered
    } else data_project$active <- rep(NA,project)
    projection_point <- nrow(data)+0.5
    data <- rbind(data,data_project)
  }
  #--------------------------------------------------------#
  # functions to optmize model and estimate the parameters #
  #--------------------------------------------------------#
  yhat <- function(par,x)
  {
    return(par[1]/(1+exp(-par[2]-par[3]*x)))
  }
  fit_curve <- function(counts,ui,ci,maxtotal=NULL)
  {
    start_point <- min(which(data[,counts] >= 1))
    y <- data[start_point:nrow(data),counts]
    tmp <- data[start_point:nrow(data),1]
    x <- cumsum(c(1,as.numeric(tmp[-1]-tmp[-length(tmp)])))
    if(counts != "recovered")
    {
      sse <- function(par)
      {
        e <- y-yhat(par,x)
        return(sum(e^2))
      }
      sse_grad <- function(par)
      {
        e <- y-yhat(par,x)
        da <- sum(-2*e*yhat(c(1,par[2:3]),x))
        db <- sum(-2*e*yhat(par,x)*(1-yhat(c(1,par[2:3]),x)))
        dc <- sum(-2*e*x*yhat(par,x)*(1-yhat(c(1,par[2:3]),x)))
        return(c(da,db,dc))
      }
      return(list(start_point=start_point,par=constrOptim(c(max(y)+1,-1,0.5),sse,sse_grad,ui=ui,ci=ci,method="BFGS")$par))
    } else
    {
      sse <- function(par)
      {
        e <- y-yhat(c(maxtotal,par),x)
        return(sum(e^2))
      }
      sse_grad <- function(par)
      {
        e <- y-yhat(c(maxtotal,par),x)
        db <- sum(-2*e*yhat(c(maxtotal,par),x)*(1-yhat(c(1,par),x)))
        dc <- sum(-2*e*x*yhat(c(maxtotal,par),x)*(1-yhat(c(1,par),x)))
        return(c(db,dc))
      }
      return(list(start_point=start_point,par=constrOptim(c(-1,0.5),sse,sse_grad,ui=ui,ci=ci,method="BFGS")$par))
    }
  }
  #-----------------#
  # confirmed cases #
  #-----------------#
  # days to run the curve on
  ndays <- 10000
  # estimate parameters
  tmp <- fit_curve("confirmed",ui=cbind(c(1,0,0,0),c(0,-1,0,0),c(0,0,1,-1)),ci=c(max(data[,"confirmed"]),0,0,-1))
  aux <- matrix(tmp$par,1,3)
  x_start <- tmp$start_point
  # fitted data and residuals
  fit_yhat <- data.frame(date=data$date[1]+1:ndays-x_start[1],confirmed=round(yhat(aux[1,],1:ndays-x_start[1])))
  fit_res <- data.frame(date=data$date,confirmed=data$confirmed-fit_yhat$confirmed[1:nrow(data)])
  # identify key points
  x_key <- 1
  x_key <- c(x_key,min(which(abs(fit_yhat$confirmed/aux[1,1]-0.125) == min(abs(fit_yhat$confirmed/aux[1,1]-0.125)))))
  x_key <- c(x_key,round(-aux[1,2]/aux[1,3]))
  x_key <- c(x_key,max(which(abs(fit_yhat$confirmed/aux[1,1]-0.875) == min(abs(fit_yhat$confirmed/aux[1,1]-0.875)))))
  x_key <- c(x_key,max(which(abs(fit_yhat$confirmed/aux[1,1]-0.975) == min(abs(fit_yhat$confirmed/aux[1,1]-0.975)))))
  names(x_key) <- c("day1","start_critical","inflection","most_critical","end_critical")
  #--------#
  # deaths #
  #--------#
  # estimate parameters
  tmp <- fit_curve("deaths",ui=cbind(c(-1,1,0,0,0),c(0,0,-1,0,0),c(0,0,0,1,-1)),ci=c(-round(aux[1,1]),max(data[,"deaths"]),0,0,-1))
  aux <- rbind(aux,tmp$par)
  x_start <- c(x_start,tmp$start_point)
  # fitted data and residuals
  fit_yhat$deaths <- round(yhat(aux[2,],1:ndays-x_start[2]))
  fit_res$deaths <- data$deaths-fit_yhat$deaths[1:nrow(data)]
  #-----------#
  # recovered #
  #-----------#
  # estimate parameters
  if(!any(is.na(data[,"recovered"])))
  {
    if(is.null(project))
    {
      tmp <- fit_curve("recovered",ui=cbind(c(-1,0,0),c(0,1,-1)),ci=c(0,0,-1),maxtotal=aux[1,1]-aux[2,1])
      aux <- rbind(aux,c(aux[1,1]-aux[2,1],tmp$par))
      x_start <- c(x_start,tmp$start_point)
    } else
    {
      tmp <- log(((aux[1,1]-aux[2,1])/data$recovered[min(which(data$recovered >= 1))])-1)/(x_key[3]-1)
      aux <- rbind(aux,c(aux[1,1]-aux[2,1],-x_key[3]*tmp,tmp))
      x_start <- c(x_start,min(which(data$recovered >= 1)))
    }
    dimnames(aux) <- list(c("confirmed","deaths","recovered"),c("a","b","c"))
    # fitted data and residuals
    fit_yhat$recovered <- round(yhat(aux[3,],1:ndays-x_start[3]))
    fit_res$recovered <- data$recovered-fit_yhat$recovered[1:nrow(data)]
  } else
  {
    tmp <- log(((aux[1,1]-aux[2,1])/(0.05*(data$confirmed[15]-data$deaths[15])))-1)/(x_key[3]-1)
    aux <- rbind(aux,c(aux[1,1]-aux[2,1],-x_key[3]*tmp,tmp))
    x_start <- c(x_start,15)
    dimnames(aux) <- list(c("confirmed","deaths","recovered"),c("a","b","c"))
    # fitted data and residuals
    fit_yhat$recovered <- round(yhat(aux[3,],1:ndays-x_start[3]))
    fit_res$recovered <- data$recovered-fit_yhat$recovered[1:nrow(data)]
  }
  #------------------------------------#
  # some touching up to wrap up things #
  #------------------------------------#
  # add fitted active cases
  fit_yhat$active <- fit_yhat$confirmed - fit_yhat$recovered - fit_yhat$deaths
  # remove projected from data
  if(!is.null(project))
  {
    data <- data[1:(nrow(data)-project),]
  }
  # warnings if numbers are too low
  if(max(data$confirmed) < 500)
  {
    if(is.null(project))
    {
      warning("Total number of confirmed cases is still very small. Estimates without projection may be unreliable.")
    } else warning("Total projected number of confirmed cases is still very small. Consider increasing the number of projected days or the rate for confirmed cases.")
  } else
  {
    if(max(data$confirmed) > 1000)
    {
      x_key[1] <- min(which(data$confirmed >= 100))
    }
  }
  #-----------#
  # make plot #
  #-----------#
  if(plot.curves)
  {
    par(mar=c(2,4,1,1))
    plot(NA,xlim=c(x_key[1],x_key[5]+10),ylim=c(0,1.05*max(aux[,1])/1000),xlab="",ylab=paste0("cumulative (x",format(1000,big.mark=","),")"),axes=FALSE)
    axis(1,pos=0,at=x_key,labels=paste(day(fit_yhat$date[x_key]),substr(month.name[month(fit_yhat$date[x_key])],1,3),substr(as.character(fit_yhat$date[x_key]),3,4),sep="/"),cex.axis=0.8)
    axis(2)
    abline(h=0)
    x_pol <- c(seq(x_key[2],x_key[5],length.out=300),seq(x_key[5],x_key[2],length.out=300))
    y_pol <- c(rep(0,300),yhat(aux["confirmed",],seq(x_key[5],x_key[2],length.out=300))/1000)
    polygon(x_pol,y_pol,col=adjustcolor(8,0.3),lty=2)
    arrows(x_key[3:4],rep(0,2),x_key[3:4],yhat(aux["confirmed",],x_key[3:4])/1000,code=0,lty=2)
    # points(x_key[3]-0.03*(x_key[5]-x_key[1]),yhat(aux[1,],x_key[3])/1000,pch=">",cex=1.25)
    polygon(x_key[3]-c(0.04,0.0175,0.04)*(x_key[5]-x_key[1]),c(0.985,1,1.015)*yhat(aux[1,],x_key[3])/1000,col=1)
    text(x_key[3]-0.03*(x_key[5]-x_key[1]),yhat(aux[1,],x_key[3])/1000,"inflection",pos=2,offset=0.6)
    points(x_key[4],1.05*yhat(aux[1,],x_key[4])/1000,pch=25,bg=1)
    text(x_key[4],1.11*yhat(aux[1,],x_key[4])/1000,"most\ncritical")
    lines(1:nrow(fit_yhat)-1,fit_yhat[,"deaths"]/1000,col=2)
    points(cumsum(c(1,as.numeric(data[-1,1]-data[-nrow(data),1]))),data$deaths/1000,pch=4,col=2,cex=0.5)
    if(any(rownames(aux) == "recovered"))
    {
      lines(1:nrow(fit_yhat)-1,fit_yhat[,"recovered"]/1000,col=3)
      points(cumsum(c(1,as.numeric(data[-1,1]-data[-nrow(data),1]))),data$recovered/1000,pch=18,col=3,cex=0.6)
    }
    lines(1:nrow(fit_yhat)-1,fit_yhat[,"confirmed"]/1000,col=4)
    points(cumsum(c(1,as.numeric(data[-1,1]-data[-nrow(data),1]))),data$confirmed/1000,pch=19,col=4,cex=0.4)
    endday <- fit_yhat$date[x_key[5]+14]
    endday <- paste(day(endday),substr(month.name[month(endday)],1,3),substr(as.character(year(endday)),3,4),sep="/")
    text(x_key[1],1.025*max(aux[,1])/1000,paste0(plot.title,": ",endday),pos=4,offset=0,cex=1.15,font=2)
    if(data$date[nrow(data)] > fit_yhat$date[x_key[5]+14])
    {
      tots <- format(data[x_key[5]+14,c("confirmed","deaths")],big.mark=",")
    } else tots <- format(fit_yhat[x_key[5]+14,c("confirmed","deaths")],big.mark=",")
    legend(x_key[1],max(aux[,1])/1000,bty="n",lty=1,pch=c(19,4),col=c(4,2),legend=paste(c("confirmed","deaths"),"=",tots))
    text(x_key[1],0.79*max(aux[,1])/1000,paste0("death rate = ",round(100*aux[2,1]/aux[1,1],1),"%"),pos=4,offset=0.2)
    text(x_key[1],0.85*max(aux[,1])/1000,paste("max active cases =",format(fit_yhat$active[x_key[4]],big.mark=",")),pos=4,offset=0.2)
  }
  #----------------#
  # prepare output #
  #----------------#
  if(return.data)
  {
    aux[,2] <- -aux[,2]/aux[,3]
    aux[,3] <- 1/aux[,3]
    names(x_start) <- c("confirmed","deaths","recovered")
    if(!is.null(project))
    {
      return(list(par=aux,day1=data$date[1]+x_start-1,key_dates=data$date[1]+x_key[-1]-1,fit=fit_yhat[1:max(nrow(data),c(max(x_key)+56)),],res=fit_res[1:nrow(data),],rates=rates.obs,projection=data_project,rates_proj=rates))
    } else return(list(par=aux,day1=data$date[1]+x_start-1,key_dates=data$date[1]+x_key[-1]-1,fit=fit_yhat[1:max(nrow(data),c(max(x_key)+56)),],res=fit_res[1:nrow(data),],rates=rates.obs))
  }
}

#' Fit the logistic curve
#'
#' This function will fit the logistic curve for an epidemic event based on the parameters and days count.
#'
#' @param par The parameters for the logistic curve.
#' @param x The days counts.
#' @return The values of the logistic curve.
#' @examples logCurve("Desktop","covid19JHU")
#' #' @seealso \code{\link{mkEpiCurves}}
#' @export
logCurve <- function(par,x)
{
  return(par[1]/(1+exp((par[2]-x)/par[3])))
}
