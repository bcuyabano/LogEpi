#' Download latest Covid-19 data from JHU database
#'
#' This function will load the latest Covid-19 data for the historical number of confirmed cases, deaths, and recovery. Both global and United States data will be downloaded. The data is provided by Johns Hopkins University (https://systems.jhu.edu/research/public-health/ncov/), available at repository https://github.com/CSSEGISandData/COVID-19
#'
#' @param folder The folder in which the downloaded data will be saved.
#' @param filename The standard filename to save the data,
#' @return
#' \describe{
#' \item{countries}{A list of the countries with records in the database.}
#' \item{US_states}{A list of the states/provinces in the US with records in the database.}
#' }
#' @examples load_JH_db("Desktop","covid19JHU")
#' @export
load_JH_db <- function(folder,filename)
{
  for(data.type in c("confirmed","deaths","recovered"))
  {
    for(loc in c("US","global"))
    {
      info.url <- paste0("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_",data.type,"_",loc,".csv")
      try(download.file(info.url,paste0(folder,"/",filename,"_",data.type,"_",loc,".csv")),silent=TRUE)
    }
  }
  for(data.type in c("confirmed","deaths","recovered"))
  {
    for(loc in c("US","global"))
    {
      info.url <- paste0("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_",data.type,"_",loc,".csv")
      try(download.file(info.url,paste0(folder,"/",filename,"_",data.type,"_",loc,".csv")),silent=TRUE)
    }
  }
  # get list of countries
  loc <- "global"
  data.type <- "confirmed"
  tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=TRUE)
  names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=FALSE,nrows=1))))
  countries <- sort(unique(tmp[,"Country/Region"]))
  # get list of US states
  loc <- "US"
  data.type <- "confirmed"
  tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=TRUE)
  names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=FALSE,nrows=1))))
  US_states <- sort(unique(tmp[,"Province_State"]))
  return(list(countries=as.character(countries),US_states=as.character(US_states)))
}

#' Extract Covid-19 data from a specific location
#'
#' This function will extract the Covid-19 data from a specific location, out of the downloaded databases
#'
#' @param location The name of the location of interest. If data="global", location is a country. If data="US", location is a state.
#' @param data The data base where the location is at. Either location="global" or location="US".
#' @param folder The folder in which the downloaded data was saved with load_JH_db().
#' @param filename The standard filename with which the data was saved with load_JH_db().
#' @return A list containing the data on confirmed cases, deaths, and recovered individuals. Data for recovered individuals is currently not available for States in the US data.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples extract_covid19_data("Michigan","US","Desktop","covid19JHU")
#' @seealso \code{\link{load_JH_db}}
#' @export
extract_covid19_data <- function(location,data,folder,filename)
{
  # dates as strings
  first.record <- as.Date("2020-01-22")
  ndays <- as.numeric(today()-first.record)
  all.days <- first.record + seq(0,ndays,1)
  dates <- paste(month(all.days),day(all.days),substr(as.character(year(all.days)),3,4),sep="/")
  # build dataset
  if(data == "global")
  {
    data.out <- list(confirmed=NULL,deaths=NULL,recovered=NULL)
    for(data.type in names(data.out))
    {
      tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=TRUE)
      names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=FALSE,nrows=1))))
      data.out[[data.type]] <- tmp[tmp[,"Country/Region"] == location,c("Province/State",names(tmp)[names(tmp) %in% dates])]
      rownames(data.out[[data.type]]) <- 1:nrow(data.out[[data.type]])
    }
  } else if(data == "US")
  {
    data.out <- list(confirmed=NULL,deaths=NULL)
    for(data.type in names(data.out))
    {
      tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=TRUE)
      names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=FALSE,nrows=1))))
      data.out[[data.type]] <- tmp[tmp[,"Province_State"] == location,c("Admin2",names(tmp)[names(tmp) %in% dates])]
      rownames(data.out[[data.type]]) <- 1:nrow(data.out[[data.type]])
    }
  }
  return(data.out)
}

#' Create epidemic table
#'
#' This function will structure the extracted Covid-19 data from a location. A specific province (or county, state, administrative region, etc) can be determined.
#'
#' @param data The dataset extracted with extract_covid19_data().
#' @param specific A specific province (or county, state, administrative region, etc). Default is specific=NULL, meaning that all areas in the location will be considered.
#' @param daily Return daily notifications instead of cumulative? Default daily=FALSE.
#' @return A data frame with the structured Covid-19 data at the location of interest.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples mkEpiTable(dataCovid,"China")
#' @examples mkEpiTable(dataCovid,"China",specific="Hubei")
#' @examples mkEpiTable(dataCovid,"China",specific=c("Hubei","Guangdong"))
#' @seealso \code{\link{load_JH_db}}
#' @seealso \code{\link{extract_covid19_data}}
#' @export
mkEpiTable <- function(data,specific=NULL,daily=FALSE)
{
  tmp <- unlist(strsplit(names(data[[1]])[2],"/"))
  dates <- as.Date(paste0(tmp[1],"-",tmp[2],"-20",tmp[3]),format="%m-%d-%Y") + 0:(ncol(data[[1]])-2)
  tmp <- data.frame(date=dates,confirmed=rep(NA,length(dates)),deaths=rep(NA,length(dates)),recovered=rep(NA,length(dates)))
  for(i in 1:length(data))
  {
    if(is.null(specific))
    {
      tmp[,names(data)[i]] <- as.numeric(apply(data[[i]][,-1],2,sum))
    } else
    {
      if(length(specific) == 1)
      {
        tmp[,names(data)[i]] <- as.numeric(data[[i]][data[[i]][,1] == specific,-1])
      } else tmp[,names(data)[i]] <- as.numeric(apply(data[[i]][data[[i]][,1] %in% specific,-1],2,sum))
    }
  }
  if(!any(is.na(tmp$recovered)))
  {
    tmp$active <- tmp$confirmed - tmp$deaths - tmp$recovered
  } else tmp$active <- rep(NA,nrow(tmp))
  if(daily)
  {
    tmp$confirmed <- c(tmp$confirmed[1],tmp$confirmed[-1]-tmp$confirmed[-nrow(tmp)])
    tmp$deaths <- c(tmp$deaths[1],tmp$deaths[-1]-tmp$deaths[-nrow(tmp)])
    if(!any(is.na(tmp$recovered)))
    {
      tmp$recovered <- c(tmp$recovered[1],tmp$recovered[-1]-tmp$recovered[-nrow(tmp)])
    }
  }
  return(tmp[tmp$confirmed > 0,])
}

#' Create epidemic curves
#'
#' This function will estimate the curves for the Covid-19 epidemic.
#'
#' @param data The epidemic table, in the format of a data frame, with columns: date, confirmed, deaths, recovered.
#' @param project An integer indicating how many days ahead should be projected. Default project=NULL indicates that no projection will be done.
#' @param rates A list of rates to project confirmed cases and deaths. If no rates are given, the average rate of the last five days in the data will be used.
#' @param plot.curves Should the curves be plotted?
#' @param plot.title A title for the plot. Recomended to use the location which the analyses refers to.
#' @param return.data Should the calculated values be returned?
#' @return
#' \describe{
#' \item{par}{The estimated parameters for the logistic curves.}
#' \item{day1}{The dates considered as x=1 to fit the logistic curves.}
#' \item{key_dates}{The important dates of the critical period.}
#' \item{fit}{The fitted values.}
#' \item{res}{The residuals of the model.}
#' \item{rates}{The epidemic rates.}
#' \item{projection}{The values projected.}
#' \item{rates_proj}{The epidemic rates used for the projection.}
#' }
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples dataChina <- mkEpiTable(dataCovid,"China")
#' @examples mkEpiCurves(dataChina)
#' @examples #---------------------------------#
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("New Zealand","global","Desktop","covid19JHU")
#' @examples dataNZ <- mkEpiTable(dataCovid,"New Zealand")
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand")
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7)
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(confirmed=1.2))
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(deaths=1.1))
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(confirmed=1.2,deaths=1.1))
#' @seealso \code{\link{load_JH_db}}
#' @seealso \code{\link{extract_covid19_data}}
#' @seealso \code{\link{mkEpiTable}}
#' @export
mkEpiCurves <- function(data,project=NULL,rates=NULL,plot.curves=TRUE,plot.title=NULL,return.data=TRUE)
{
  #--------------------#
  # first preparations #
  #--------------------#
  # cut data to contain only records with confirmed > 0
  data <- data[min(which(data$confirmed >= 1)):nrow(data),]
  # calculate rates
  rates.obs <- data.frame(date=data$date,confirmed=rep(0,nrow(data)),deaths=rep(0,nrow(data)),recovered=rep(0,nrow(data)))
  tmp <- c(0,data$confirmed[-1]/data$confirmed[-nrow(data)])
  rates.obs$confirmed <- c(rep(0,min(which(data$confirmed > 0))),tmp[(min(which(data$confirmed > 0))+1):nrow(data)])
  tmp <- c(0,data$deaths[-1]/data$deaths[-nrow(data)])
  rates.obs$deaths <- c(rep(0,min(which(data$deaths > 0))),tmp[(min(which(data$deaths > 0))+1):nrow(data)])
  if(!any(is.na(data[,"recovered"])))
  {
    tmp <- c(0,data$recovered[-1]/data$recovered[-nrow(data)])
    rates.obs$recovered <- c(rep(0,min(which(data$recovered > 0))),tmp[(min(which(data$recovered > 0))+1):nrow(data)])
  }
  #----------------#
  # add projection #
  #----------------#
  if(!is.null(project))
  {
    if(is.null(rates))
    {
      rates <- list(confirmed=mean(rev(rates.obs$confirmed)[1:5]),deaths=mean(rev(rates.obs$deaths)[1:5]))
    } else
    {
      if(!any(names(rates) == "confirmed"))
      {
        rates$confirmed=max(c(1,mean(rev(rates.obs$confirmed)[1:5])))
      }
      if(!any(names(rates) == "deaths"))
      {
        rates$deaths=max(c(1,mean(rev(rates.obs$deaths)[1:5])))
      }
    }
    data_project <- data.frame(date=data$date[nrow(data)]+1:project,confirmed=rep(NA,project),deaths=rep(NA,project),recovered=rep(max(data$recovered),project))
    data_project$confirmed <- round(data$confirmed[nrow(data)]*rates$confirmed^(1:project))
    data_project$deaths <- round(data$deaths[nrow(data)]*rates$deaths^(1:project))
    if(!any(is.na(data[,"recovered"])))
    {
      data_project$active <- data_project$confirmed - data_project$deaths - data_project$recovered
    } else data_project$active <- rep(NA,project)
    projection_point <- nrow(data)+0.5
    data <- rbind(data,data_project)
  }
  #--------------------------------------------------------#
  # functions to optmize model and estimate the parameters #
  #--------------------------------------------------------#
  yhat <- function(par,x)
  {
    return(par[1]/(1+exp(-par[2]-par[3]*x)))
  }
  fit_curve <- function(counts,ui,ci,maxtotal=NULL)
  {
    start_point <- min(which(data[,counts] >= 1))
    y <- data[start_point:nrow(data),counts]
    tmp <- data[start_point:nrow(data),1]
    x <- cumsum(c(1,as.numeric(tmp[-1]-tmp[-length(tmp)])))
    if(counts != "recovered")
    {
      sse <- function(par)
      {
        e <- y-yhat(par,x)
        return(sum(e^2))
      }
      sse_grad <- function(par)
      {
        e <- y-yhat(par,x)
        da <- sum(-2*e*yhat(c(1,par[2:3]),x))
        db <- sum(-2*e*yhat(par,x)*(1-yhat(c(1,par[2:3]),x)))
        dc <- sum(-2*e*x*yhat(par,x)*(1-yhat(c(1,par[2:3]),x)))
        return(c(da,db,dc))
      }
      return(list(start_point=start_point,par=constrOptim(c(max(y)+1,-1,0.5),sse,sse_grad,ui=ui,ci=ci,method="BFGS")$par))
    } else
    {
      sse <- function(par)
      {
        e <- y-yhat(c(maxtotal,par),x)
        return(sum(e^2))
      }
      sse_grad <- function(par)
      {
        e <- y-yhat(c(maxtotal,par),x)
        db <- sum(-2*e*yhat(c(maxtotal,par),x)*(1-yhat(c(1,par),x)))
        dc <- sum(-2*e*x*yhat(c(maxtotal,par),x)*(1-yhat(c(1,par),x)))
        return(c(db,dc))
      }
      return(list(start_point=start_point,par=constrOptim(c(-1,0.5),sse,sse_grad,ui=ui,ci=ci,method="BFGS")$par))
    }
  }
  #-----------------------#
  # model confirmed cases #
  #-----------------------#
  # days to run the curve on
  ndays <- 10000
  # estimate parameters
  tmp <- fit_curve("confirmed",ui=cbind(c(1,0,0,0),c(0,-1,0,0),c(0,0,1,-1)),ci=c(max(data[,"confirmed"]),0,0,-1))
  aux <- matrix(tmp$par,1,3)
  x_start <- tmp$start_point
  # fitted data and residuals
  fit_yhat <- data.frame(date=data$date[1]+1:ndays-x_start[1],confirmed=round(yhat(aux[1,],1:ndays-x_start[1])))
  fit_res <- data.frame(date=data$date,confirmed=data$confirmed-fit_yhat$confirmed[1:nrow(data)])
  # identify key points
  x_key <- 1
  x_key <- c(x_key,min(which(abs(fit_yhat$confirmed/aux[1,1]-0.125) == min(abs(fit_yhat$confirmed/aux[1,1]-0.125)))))
  x_key <- c(x_key,round(-aux[1,2]/aux[1,3]))
  x_key <- c(x_key,max(which(abs(fit_yhat$confirmed/aux[1,1]-0.875) == min(abs(fit_yhat$confirmed/aux[1,1]-0.875)))))
  x_key <- c(x_key,max(which(abs(fit_yhat$confirmed/aux[1,1]-0.975) == min(abs(fit_yhat$confirmed/aux[1,1]-0.975)))))
  names(x_key) <- c("day1","start_critical","inflection","most_critical","end_critical")
  #--------------#
  # model deaths #
  #--------------#
  # estimate parameters
  tmp <- fit_curve("deaths",ui=cbind(c(-1,1,0,0,0),c(0,0,-1,0,0),c(0,0,0,1,-1)),ci=c(-round(aux[1,1]),max(data[,"deaths"]),0,0,-1))
  aux <- rbind(aux,tmp$par)
  x_start <- c(x_start,tmp$start_point)
  # fitted data and residuals
  fit_yhat$deaths <- round(yhat(aux[2,],1:ndays-x_start[2]))
  fit_res$deaths <- data$deaths-fit_yhat$deaths[1:nrow(data)]
  #-----------------#
  # model recovered #
  #-----------------#
  # estimate parameters
  if(!any(is.na(data[,"recovered"])))
  {
    if(is.null(project))
    {
      tmp <- fit_curve("recovered",ui=cbind(c(-1,0,0),c(0,1,-1)),ci=c(0,0,-1),maxtotal=aux[1,1]-aux[2,1])
      aux <- rbind(aux,c(aux[1,1]-aux[2,1],tmp$par))
      x_start <- c(x_start,tmp$start_point)
    } else
    {
      tmp <- log(((aux[1,1]-aux[2,1])/data$recovered[min(which(data$recovered >= 1))])-1)/(x_key[3]-1)
      aux <- rbind(aux,c(aux[1,1]-aux[2,1],-x_key[3]*tmp,tmp))
      x_start <- c(x_start,min(which(data$recovered >= 1)))
    }
    dimnames(aux) <- list(c("confirmed","deaths","recovered"),c("a","b","c"))
    # fitted data and residuals
    fit_yhat$recovered <- round(yhat(aux[3,],1:ndays-x_start[3]))
    fit_res$recovered <- data$recovered-fit_yhat$recovered[1:nrow(data)]
  } else
  {
    tmp <- log(((aux[1,1]-aux[2,1])/(0.05*(data$confirmed[15]-data$deaths[15])))-1)/(x_key[3]-1)
    aux <- rbind(aux,c(aux[1,1]-aux[2,1],-x_key[3]*tmp,tmp))
    x_start <- c(x_start,15)
    dimnames(aux) <- list(c("confirmed","deaths","recovered"),c("a","b","c"))
    # fitted data and residuals
    fit_yhat$recovered <- round(yhat(aux[3,],1:ndays-x_start[3]))
    fit_res$recovered <- data$recovered-fit_yhat$recovered[1:nrow(data)]
  }
  #------------------------------------#
  # some touching up to wrap up things #
  #------------------------------------#
  # add fitted active cases
  fit_yhat$active <- fit_yhat$confirmed - fit_yhat$recovered - fit_yhat$deaths
  fit_yhat$recovered[fit_yhat$active < 0] <- fit_yhat$recovered[fit_yhat$active < 0] + fit_yhat$active[fit_yhat$active < 0]
  fit_yhat$active <- fit_yhat$confirmed - fit_yhat$recovered - fit_yhat$deaths
  fit_yhat$date <- fit_yhat$date-1
  fit_yhat <- fit_yhat[-1,]
  # remove projected from data
  if(!is.null(project))
  {
    data <- data[1:(nrow(data)-project),]
  }
  # warnings if numbers are too low
  if(max(data$confirmed) < 500)
  {
    if(is.null(project))
    {
      warning("Total number of confirmed cases is still very small. Estimates without projection may be unreliable.")
    } else warning("Total projected number of confirmed cases is still very small. Consider increasing the number of projected days or the rate for confirmed cases.")
  } else
  {
    if(max(data$confirmed) > 1000)
    {
      x_key[1] <- min(which(data$confirmed >= 100))
    }
  }
  # prepare output
  if(return.data)
  {
    aux[,2] <- -aux[,2]/aux[,3]
    aux[,3] <- 1/aux[,3]
    names(x_start) <- c("confirmed","deaths","recovered")
  }
  if(!is.null(project))
  {
    fitdata <- list(par=aux,day1=data$date[1]+x_start-1,key_dates=data$date[1]+x_key[-1]-1,fit=fit_yhat[1:max(nrow(data),c(max(x_key)+56)),],res=fit_res[1:nrow(data),],rates=rates.obs,projection=data_project,rates_proj=rates)
  } else fitdata <- list(par=aux,day1=data$date[1]+x_start-1,key_dates=data$date[1]+x_key[-1]-1,fit=fit_yhat[1:max(nrow(data),c(max(x_key)+56)),],res=fit_res[1:nrow(data),],rates=rates.obs)
  #-------------------------#
  # create plot if required #
  #-------------------------#
  if(plot.curves)
  {
    mkEpiPlot(data,fitdata,"cumulative",healthsystem=NULL,hospital.cases=NULL,plot.title=plot.title)
  }
  #-------------#
  # return data #
  #-------------#
  fitdata
}

#' Fit the logistic curve
#'
#' This function will fit the logistic curve for an epidemic event based on the parameters and days count.
#'
#' @param par The parameters for the logistic curve.
#' @param x The days counts.
#' @return The values of the logistic curve.
#' @examples logCurve("Desktop","covid19JHU")
#' @seealso \code{\link{mkEpiCurves}}
#' @export
logCurve <- function(par,x)
{
  return(par[1]/(1+exp((par[2]-x)/par[3])))
}

#' Create epidemic plots
#'
#' This function will make the epidemic plots.
#'
#' @param data The epidemic table, in the format of a data frame, with columns: date, confirmed, deaths, recovered.
#' @param fitdata The output from mkEpiCurves.
#' @param type The type of plot to produce \code{"cumulative"} for the cumulative curves or \code{"active"} for the curve of active cases.
#' @param healthsystem Information about the health system. A data frame \code{(beds,phys,nurs)} with the total number of beds, physicians, and nurses, respectively.
#' @param hospital.cases The proportion of active cases that require some hospitalization and the proportion of cases that are severe. If \code{NULL}, the vlues are set to \code{hospital.cases=c(0.2,0.05)}.
#' @param hide.max.active Should the number of maximum active cases be printed? TRUE/FALSE.
#' @param plot.recovered Should the fitted curve of recovery be ploted? TRUE/FALSE
#' @return The required plot.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples dataChina <- mkEpiTable(dataCovid,"China")
#' @examples fitCovid <- mkEpiCurves(dataChina,plot.curves=FALSE)
#' @examples mkEpiPlot(dataCovid,fitCovid,type="cumulative")
#' @examples mkEpiPlot(dataCovid,fitCovid,type="active")
#' @seealso \code{\link{mkEpiCurves}}
#' @seealso \code{\link{mkEpiTable}}
#' @export
mkEpiPlot <- function(data,fitdata,type="cumulative",healthsystem=NULL,hospital.cases=NULL,plot.title=NULL,hide.max.active=FALSE,plot.recovered=TRUE)
{
  if(type == "cumulative")
  {
    if(as.numeric(fitdata$key_dates[1] - today()) >= 7)
    {
      keyd <- c(today(),fitdata$key_dates)
    } else keyd <- c(max(c(fitdata$key_dates[1]-7,data$date[1])),fitdata$key_dates)
    names(keyd) <- c("",names(fitdata$key_dates))
    fits <- fitdata$fit[fitdata$fit$date >= keyd[1],]
    fits <- fits[1:min(c(which(fits$date == keyd["end_critical"]+14),nrow(fits))),]
    datacut <- data[data$date >= min(fits$date) & data$date <= max(fits$date),]
    par(mar=c(2,3.5,1,1))
    plot(NA,xlim=c(1,nrow(fits)),ylim=c(0,1.05*max(fits$confirmed)/1000),xlab="",ylab="",axes=FALSE)
    mtext("cumulative (x1,000)",side=2,line=2)
    abline(h=0)
    abline(v=0)
    axis(1,at=which(fits$date %in% keyd),labels=paste(day(keyd),substr(month.name[month(keyd)],1,3),sep="/"),pos=0,cex.axis=0.8)
    axis(2,pos=0)
    x <- which(fits$date == keyd["start_critical"]):which(fits$date == keyd["end_critical"])
    polygon(c(x,rev(x)),c(fits$confirmed[x],rep(0,length(x)))/1000,col=adjustcolor(8,0.35),lty=2)
    lines(rep(which(fits$date == keyd["inflection"]),2),c(0,fits$confirmed[which(fits$date == keyd["inflection"])])/1000,lty=2)
    lines(rep(which(fits$date == keyd["most_critical"]),2),c(0,fits$confirmed[which(fits$date == keyd["most_critical"])])/1000,lty=2)
    if(plot.recovered)
    {
      lines(1:nrow(fits),fits$recovered/1000,lwd=1.5,col=3)
    }
    lines(1:nrow(fits),fits$deaths/1000,lwd=1.5,col=2)
    lines(1:nrow(fits),fits$confirmed/1000,lwd=1.5,col=4)
    if(nrow(datacut) > 0)
    {
      if(plot.recovered)
      {
        points(1:nrow(datacut),datacut$recovered/1000,col=3,pch=23,cex=0.5)
      }
      points(1:nrow(datacut),datacut$deaths/1000,col=2,pch=4,cex=0.5)
      points(1:nrow(datacut),datacut$confirmed/1000,col=4,pch=19,cex=0.5)
    }
    par(new=TRUE)
    plot(NA,xlim=c(0,1),ylim=c(0,1),axes=FALSE,xlab="",ylab="")
    polygon(which(fits$date == keyd["inflection"])/nrow(fits)-c(0.045,0.025,0.045),fits$confirmed[which(fits$date == keyd["inflection"])]/(1.05*max(fits$confirmed))+c(-0.0125,0,0.0125),col=1)
    text(which(fits$date == keyd["inflection"])/nrow(fits)-0.035,fits$confirmed[which(fits$date == keyd["inflection"])]/(1.05*max(fits$confirmed)),"inflection",pos=2)
    points((which(fits$date == keyd["most_critical"])-0.5)/nrow(fits),0.04+fits$confirmed[which(fits$date == keyd["most_critical"])]/(1.05*max(fits$confirmed)),pch=25,bg=1)
    text((which(fits$date == keyd["most_critical"])-0.5)/nrow(fits),0.045+fits$confirmed[which(fits$date == keyd["most_critical"])]/(1.05*max(fits$confirmed)),"most\ncritical",pos=3)
    if(plot.recovered)
    {
      text(rep(1,3),0.025+as.numeric(fits[nrow(fits),2:4])/(1.05*max(fits$confirmed)),c("confirmed","deaths","recovered"),pos=2,offset=0)
    } else text(rep(1,2),0.025+as.numeric(fits[nrow(fits),2:3])/(1.05*max(fits$confirmed)),c("confirmed","deaths"),pos=2,offset=0)
    if(is.null(plot.title))
    {
      text(0,1,paste0("Totals at ",day(fits$date[nrow(fits)]),"/",substr(month.name[month(fits$date[nrow(fits)])],1,3),"/",year(fits$date[nrow(fits)])),pos=4,font=2)
      text(c(0,0),c(0.93,0.88),paste(c("confirmed","deaths"),"=",format(c(as.numeric(fits[nrow(fits),c("confirmed","deaths")])),big.mark=",")),pos=4)
      text(0,0.83,paste0("death rate = ",100*round(fits$deaths[nrow(fits)]/fits$confirmed[nrow(fits)],3),"%"),pos=4)
      if(!hide.max.active)
      {
        text(0,0.78,paste("max active cases =",format(max(fits$active),big.mark=",")),pos=4)
      }
    } else
    {
      text(0,1,plot.title,pos=4,font=2)
      text(0,0.93,paste0("Totals at ",day(fits$date[nrow(fits)]),"/",substr(month.name[month(fits$date[nrow(fits)])],1,3),"/",year(fits$date[nrow(fits)])),pos=4,font=2)
      text(c(0,0),c(0.86,0.81),paste(c("confirmed","deaths"),"=",format(c(as.numeric(fits[nrow(fits),c("confirmed","deaths")])),big.mark=",")),pos=4)
      text(0,0.76,paste0("death rate = ",100*round(fits$deaths[nrow(fits)]/fits$confirmed[nrow(fits)],3),"%"),pos=4)
      if(!hide.max.active)
      {
        text(0,0.71,paste("max active cases =",format(max(fits$active),big.mark=",")),pos=4)
      }
    }
  } else if(type == "active")
  {
    if(as.numeric(fitdata$key_dates[1] - today()) >= 21)
    {
      keyd <- c(today(),fitdata$key_dates)
    } else keyd <- c(max(c(fitdata$key_dates[1]-21,data$date[1])),fitdata$key_dates)
    names(keyd) <- c("",names(fitdata$key_dates))
    fits <- fitdata$fit[fitdata$fit$date >= keyd[1],]
    fits <- fits[1:min(c(nrow(fits),2*which(fits$date == keyd["end_critical"]))),]
    datacut <- data[data$date >= min(fits$date) & data$date <= max(fits$date),]
    if(is.null(hospital.cases))
    {
      hospital.cases <- c(0.2,0.05)
    }
    par(mar=c(2,4,1,1))
    plot(datacut$active/1000,type="h",col=8,xlim=c(1,nrow(fits)),ylim=c(0,1.05*max(fits$active)/1000),ylab="",axes=FALSE)
    mtext("active cases (x1,000)",side=2,line=2.5)
    abline(h=0)
    abline(v=-1)
    if(is.null(healthsystem) || sum(0.2*fits$active > 0.05*as.numeric(healthsystem["beds"])) == 0)
    {
      x <- which(fits$date %in% keyd[c("start_critical","end_critical")])
      x <- x + c(0,15)
    } else x <- range(which(0.2*fits$active > 0.05*as.numeric(healthsystem["beds"])))
    axis(1,at=x,labels=paste(day(fits$date[x]),substr(month.name[month(fits$date[x])],1,3),year(fits$date[x]),sep="/"),pos=0)
    axis(2,pos=-1)
    lines(1:nrow(fits),fits$active/1000,lwd=3.5,col=4)
    lines(1:nrow(fits),hospital.cases[1]*fits$active/1000,lwd=2,col=2,lty=2)
    lines(1:nrow(fits),hospital.cases[2]*fits$active/1000,lwd=2,col=2)
    lines(c(-5,which(fits$active == max(fits$active))-1),rep(max(fits$active)/1000,2),lty=2,col=4)
    if(!is.null(healthsystem))
    {
      abline(h=0.05*healthsystem["beds"]/1000)
    }
    par(new=TRUE)
    plot(NA,xlim=c(0,1),ylim=c(0,1),axes=FALSE,xlab="",ylab="")
    if(!hide.max.active)
    {
      text(0,0.025+max(fits$active)/(1.05*max(fits$active)),labels=format(max(fits$active),big.mark=","),pos=4)
    }
    if(!is.null(plot.title))
    {
      text(0.54,1,plot.title,pos=4,font=2)
      legend(0.54,0.975,bty="n",cex=0.95,lty=c(1,2,1,1,1),lwd=c(2,1.5,1.5,1,1),col=c(4,2,2,8,1),legend=c("active cases",paste0("need some care (~",100*hospital.cases[1],"%)"),paste0("severe cases (~",100*hospital.cases[2],"%)"),"real numbers",paste0("HS capacity",ifelse(is.null(healthsystem)," (NA)",""))))
    } else legend(0.54,1,bty="n",cex=0.95,lty=c(1,2,1,1,1),lwd=c(2,1.5,1.5,1,1),col=c(4,2,2,8,1),legend=c("active cases",paste0("need some care (~",100*hospital.cases[1],"%)"),paste0("severe cases (~",100*hospital.cases[2],"%)"),"real numbers",paste0("HS capacity",ifelse(is.null(healthsystem)," (NA)",""))))
  }
}

#' Create comparative epidemic plots
#'
#' This function will make comparatice epidemic plots.
#'
#' @param location The name of the location of interest. If data="global", location is a country. If data="US", location is a state.
#' @param data The data base where the location is at. Either location="global" or location="US".
#' @param folder The folder in which the downloaded data was saved with load_JH_db().
#' @param filename The standard filename with which the data was saved with load_JH_db().
#' @param cases.count The minimum number of cases from which the data should be considered. Default is 100.
#' @return A comparative epidemic plot.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples mkEpiComparePlot(location=c("Italy","Spain","United Kingdom","France"),data="global","Desktop","covid19JHU")
#' @examples mkEpiComparePlot(location=c("New York","New Jersey","California"),data="US","Desktop","covid19JHU")
#' @export
mkEpiComparePlot <- function(location,data,folder,filename,cases.count=100)
{
  CovidData <- list(location,counts=list(cases=NULL,death=NULL),pop.prop=list(cases=NULL,death=NULL),rates=list(cases=NULL,death=NULL))
  names(CovidData)[1] <- ifelse(data == "global","country","state")
  CovidData
  if(data == "global")
  {
    pop <- CountryData[CountryData$country %in% location,]
  } else pop <- USstatesData[USstatesData$state %in% location,]

  for(k in CovidData[[1]])
  {
    tmp <- mkEpiTable(extract_covid19_data(location=k,data=data,folder,filename))
    tmp <- tmp[tmp$confirmed >= cases.count,]
    if(is.null(CovidData$counts$cases))
    {
      CovidData$counts$cases <- as.data.frame(matrix(tmp$confirmed,nrow=1))
      CovidData$pop.prop$cases <- as.data.frame(matrix(tmp$confirmed,nrow=1)/pop[pop[,1] == k,2])
    } else
    {
      CovidData$counts$cases <- rbind.fill(CovidData$counts$cases,as.data.frame(matrix(tmp$confirmed,nrow=1)))
      CovidData$pop.prop$cases <- rbind.fill(CovidData$pop.prop$cases,as.data.frame(matrix(tmp$confirmed,nrow=1)/pop[pop[,1] == k,2]))
    }
    if(is.null(CovidData$counts$death))
    {
      CovidData$counts$death <- as.data.frame(matrix(tmp$deaths,nrow=1))
      CovidData$pop.prop$death <- as.data.frame(matrix(tmp$deaths,nrow=1)/pop[pop[,1] == k,2])
    } else
    {
      CovidData$counts$death <- rbind.fill(CovidData$counts$death,as.data.frame(matrix(tmp$deaths,nrow=1)))
      CovidData$pop.prop$death <- rbind.fill(CovidData$pop.prop$death,as.data.frame(matrix(tmp$deaths,nrow=1)/pop[pop[,1] == k,2]))
    }
    tmp <- mkEpiCurves(tmp,plot.curves=FALSE)$rates
    if(is.null(CovidData$rates$cases))
    {
      CovidData$rates$cases <- as.data.frame(matrix(tmp$confirmed,nrow=1)-1)
    } else CovidData$rates$cases <- rbind.fill(CovidData$rates$cases,as.data.frame(matrix(tmp$confirmed,nrow=1)-1))
    if(is.null(CovidData$rates$death))
    {
      CovidData$rates$death <- as.data.frame(matrix(tmp$confirmed,nrow=1)-1)
    } else CovidData$rates$death <- rbind.fill(CovidData$rates$death,as.data.frame(matrix(tmp$confirmed,nrow=1)-1))
  }
  names(CovidData$counts$cases) <- paste0("day",1:ncol(CovidData$counts$cases))
  names(CovidData$counts$death) <- paste0("day",1:ncol(CovidData$counts$death))
  names(CovidData$pop.prop$cases) <- paste0("day",1:ncol(CovidData$counts$cases))
  names(CovidData$pop.prop$death) <- paste0("day",1:ncol(CovidData$counts$death))
  names(CovidData$rates$cases) <- paste0("day",1:ncol(CovidData$rates$cases))
  names(CovidData$rates$death) <- paste0("day",1:ncol(CovidData$rates$death))
  CovidData$rates$cases[,1] <- 1
  CovidData$rates$death[,1] <- 1
  # make plots
  col.plot <- qualitative_hcl(length(CovidData[[1]]))
  for(data.vals in c("cases","death"))
  {
    data.type <- "pop.prop"
    par(mar=c(4.25,4.25,2,1))
    plot(NA,xlim=c(1,ncol(CovidData[[data.type]][[data.vals]])+5),ylim=range(CovidData[[data.type]][[data.vals]]/ifelse(data.type == "counts",1000,ifelse(data.type == "pop.prop",1/1000,1)),na.rm=TRUE),xlab=paste("days after",cases.count,"cases"),ylab=ifelse(data.type == "counts","(x 1,000)",ifelse(data.type == "pop.prop","(per 1,000 inhabitants)","")),main=paste0(data.vals,ifelse(data.vals == "cases","","s")))
    for(i in 1:length(CovidData[[1]]))
    {
      lines(1:ncol(CovidData[[data.type]][[data.vals]]),CovidData[[data.type]][[data.vals]][i,]/ifelse(data.type == "counts",1000,ifelse(data.type == "pop.prop",1/1000,1)),lwd=1.5,col=col.plot[i])
      text(max(which(!is.na(CovidData[[data.type]][[data.vals]][i,]))),CovidData[[data.type]][[data.vals]][i,max(which(!is.na(CovidData[[data.type]][[data.vals]][i,])))]/ifelse(data.type == "counts",1000,ifelse(data.type == "pop.prop",1/1000,1)),labels=CovidData[[1]][i],pos=4,offset=0.25,cex=0.75,col=col.plot[i])
    }
  }
  data.type <- "counts"
  par(mar=c(4.25,4.25,2,1))
  plot(NA,xlim=c(1,ncol(CovidData[[data.type]]$cases)+5),ylim=100*range(CovidData[[data.type]]$death/CovidData[[data.type]]$cases,na.rm=TRUE),xlab=paste("days after",cases.count,"cases"),ylab="%",main="death rate")
  for(i in 1:length(CovidData[[1]]))
  {
    lines(1:ncol(CovidData[[data.type]]$cases),100*CovidData[[data.type]]$death[i,]/CovidData[[data.type]]$cases[i,],lwd=1.5,col=col.plot[i])
    text(max(which(!is.na(CovidData[[data.type]]$cases[i,]))),100*CovidData[[data.type]]$death[i,max(which(!is.na(CovidData[[data.type]]$cases[i,])))]/CovidData[[data.type]]$cases[i,max(which(!is.na(CovidData[[data.type]]$cases[i,])))],labels=CovidData[[1]][i],pos=4,offset=0.25,cex=0.75,col=col.plot[i])
  }
  return(CovidData)
}
