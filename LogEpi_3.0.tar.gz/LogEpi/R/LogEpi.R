#' Download latest Covid-19 data from JHU database
#'
#' This function will load the latest Covid-19 data for the historical number of confirmed cases, deaths, and recovery. Both global and United States data will be downloaded. The data is provided by Johns Hopkins University (https://systems.jhu.edu/research/public-health/ncov/), available at repository https://github.com/CSSEGISandData/COVID-19
#'
#' @param folder The folder in which the downloaded data will be saved.
#' @param filename The standard filename to save the data,
#' @return
#' \describe{
#' \item{countries}{A list of the countries with records in the database.}
#' \item{US_states}{A list of the states/provinces in the US with records in the database.}
#' }
#' @examples load_JH_db("Desktop","covid19JHU")
#' @export
load_JH_db <- function(folder,filename)
{
  for(data.type in c("confirmed","deaths","recovered"))
  {
    for(loc in c("US","global"))
    {
      info.url <- paste0("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_",data.type,"_",loc,".csv")
      try(download.file(info.url,paste0(folder,"/",filename,"_",data.type,"_",loc,".csv")),silent=TRUE)
    }
  }
  for(data.type in c("confirmed","deaths","recovered"))
  {
    for(loc in c("US","global"))
    {
      info.url <- paste0("https://raw.githubusercontent.com/CSSEGISandData/COVID-19/master/csse_covid_19_data/csse_covid_19_time_series/time_series_covid19_",data.type,"_",loc,".csv")
      try(download.file(info.url,paste0(folder,"/",filename,"_",data.type,"_",loc,".csv")),silent=TRUE)
    }
  }
  # get list of countries
  loc <- "global"
  data.type <- "confirmed"
  tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=TRUE)
  names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=FALSE,nrows=1))))
  countries <- sort(unique(tmp[,"Country/Region"]))
  # get list of US states
  loc <- "US"
  data.type <- "confirmed"
  tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=TRUE)
  names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",loc,".csv"),sep=",",header=FALSE,nrows=1))))
  US_states <- sort(unique(tmp[,"Province_State"]))
  return(list(countries=as.character(countries),US_states=as.character(US_states)))
}

#' Extract Covid-19 data from a specific location
#'
#' This function will extract the Covid-19 data from a specific location, out of the downloaded databases
#'
#' @param location The name of the location of interest. If data="global", location is a country. If data="US", location is a state.
#' @param data The data base where the location is at. Either location="global" or location="US".
#' @param folder The folder in which the downloaded data was saved with load_JH_db().
#' @param filename The standard filename with which the data was saved with load_JH_db().
#' @return A list containing the data on confirmed cases, deaths, and recovered individuals. Data for recovered individuals is currently not available for States in the US data.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples extract_covid19_data("Michigan","US","Desktop","covid19JHU")
#' @seealso \code{\link{load_JH_db}}
#' @export
extract_covid19_data <- function(location,data,folder,filename)
{
  # dates as strings
  first.record <- as.Date("2020-01-22")
  ndays <- as.numeric(today()-first.record)
  all.days <- first.record + seq(0,ndays,1)
  dates <- paste(month(all.days),day(all.days),substr(as.character(year(all.days)),3,4),sep="/")
  # build dataset
  if(data == "global")
  {
    data.out <- list(confirmed=NULL,deaths=NULL,recovered=NULL)
    for(data.type in names(data.out))
    {
      tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=TRUE)
      names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=FALSE,nrows=1))))
      data.out[[data.type]] <- tmp[tmp[,"Country/Region"] == location,c("Province/State",names(tmp)[names(tmp) %in% dates])]
      rownames(data.out[[data.type]]) <- 1:nrow(data.out[[data.type]])
    }
  } else if(data == "US")
  {
    data.out <- list(confirmed=NULL,deaths=NULL)
    for(data.type in names(data.out))
    {
      tmp <- read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=TRUE)
      names(tmp) <- as.character(t(as.matrix(read.csv(paste0(folder,"/",filename,"_",data.type,"_",data,".csv"),sep=",",header=FALSE,nrows=1))))
      data.out[[data.type]] <- tmp[tmp[,"Province_State"] == location,c("Admin2",names(tmp)[names(tmp) %in% dates])]
      rownames(data.out[[data.type]]) <- 1:nrow(data.out[[data.type]])
    }
  }
  return(data.out)
}

#' Create epidemic table
#'
#' This function will structure the extracted Covid-19 data from a location. A specific province (or county, state, administrative region, etc) can be determined.
#'
#' @param data The dataset extracted with extract_covid19_data().
#' @param specific A specific province (or county, state, administrative region, etc). Default is specific=NULL, meaning that all areas in the location will be considered.
#' @param daily Return daily notifications instead of cumulative? Default daily=FALSE.
#' @return A data frame with the structured Covid-19 data at the location of interest.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples mkEpiTable(dataCovid,"China")
#' @examples mkEpiTable(dataCovid,"China",specific="Hubei")
#' @examples mkEpiTable(dataCovid,"China",specific=c("Hubei","Guangdong"))
#' @seealso \code{\link{load_JH_db}}
#' @seealso \code{\link{extract_covid19_data}}
#' @export
mkEpiTable <- function(data,specific=NULL,daily=FALSE)
{
  tmp <- unlist(strsplit(names(data[[1]])[2],"/"))
  dates <- as.Date(paste0(tmp[1],"-",tmp[2],"-20",tmp[3]),format="%m-%d-%Y") + 0:(ncol(data[[1]])-2)
  tmp <- data.frame(date=dates,confirmed=rep(NA,length(dates)),deaths=rep(NA,length(dates)),recovered=rep(NA,length(dates)))
  for(i in 1:length(data))
  {
    if(is.null(specific))
    {
      tmp[,names(data)[i]] <- as.numeric(apply(data[[i]][,-1],2,sum))
    } else
    {
      if(length(specific) == 1)
      {
        tmp[,names(data)[i]] <- as.numeric(data[[i]][data[[i]][,1] == specific,-1])
      } else tmp[,names(data)[i]] <- as.numeric(apply(data[[i]][data[[i]][,1] %in% specific,-1],2,sum))
    }
  }
  if(!any(is.na(tmp$recovered)))
  {
    tmp$active <- tmp$confirmed - tmp$deaths - tmp$recovered
  } else tmp$active <- rep(NA,nrow(tmp))
  if(daily)
  {
    tmp$confirmed <- c(tmp$confirmed[1],tmp$confirmed[-1]-tmp$confirmed[-nrow(tmp)])
    tmp$deaths <- c(tmp$deaths[1],tmp$deaths[-1]-tmp$deaths[-nrow(tmp)])
    if(!any(is.na(tmp$recovered)))
    {
      tmp$recovered <- c(tmp$recovered[1],tmp$recovered[-1]-tmp$recovered[-nrow(tmp)])
    }
  }
  return(tmp[tmp$confirmed > 0,])
}

#' Fit the logistic curve
#'
#' This function will fit the logistic curve for an epidemic event based on the parameters and days count.
#'
#' @param par The parameters for the logistic curve.
#' @param t The days counts.
#' @param X Covariates, if considered. Default is \code{X=NULL}.
#' @return The values of the logistic curve.
#' @examples logCurve("Desktop","covid19JHU")
#' @seealso \code{\link{mkEpiCurves}}
#' @export
logCurve <- function(par,t,X=NULL)
{
  if(is.null(X)){
    yh <- par[1]/(1+exp((par[2]-t)/par[3]))
  } else{
    if(class(X) == "matrix"){
      yh <- par[1]/(1+exp((par[2]-t)/par[3]+as.numeric(X%*%par[4:length(par)])))
    } else yh <- par[1]/(1+exp((par[2]-t)/par[3]+X*par[4]))
  }
  return(yh)
}

#' Create epidemic curves
#'
#' This function will estimate the logistic curves for the Covid-19 epidemic, by default accounting only for the days passed since the start of the epidemic. Covariates can be added to fit the curve.
#'
#' @param data The epidemic table, in the format of a data frame, with columns: date, confirmed, deaths, recovered.
#' @param X Covariates to add to the logistic curve. Must be a list in which covariates for confirmed, deaths, and recovery are given. Examples: \code{X=list(confirmed=X1,deaths=X2,recovered=X3)}, {X=list(confirmed=X1)}.
#' @param project An integer indicating how many days ahead should be projected. Default project=NULL indicates that no projection will be done.
#' @param rates A list of rates to project confirmed cases and deaths. If no rates are given, the average rate of the last five days in the data will be used.
#' @param plot.curves Should the curves be plotted?
#' @param plot.title A title for the plot. Recomended to use the location which the analyses refers to.
#' @param plot.as.panel If \code{plot.curves=TRUE}, should plots be output in a panel, or individually?
#' @param country If the data belongs to a single country, adding the country's name here will allow to search if data on the health system is available.
#' @return
#' \describe{
#' \item{par}{The estimated parameters for the logistic curves.}
#' \item{fit}{The fitted values.}
#' \item{res}{The residuals of the model.}
#' \item{rates}{The epidemic rates.}
#' \item{projection}{The values projected.}
#' \item{rates_proj}{The epidemic rates used for the projection.}
#' }
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("China","global","Desktop","covid19JHU")
#' @examples dataChina <- mkEpiTable(dataCovid,"China")
#' @examples mkEpiCurves(dataChina)
#' @examples #---------------------------------#
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples dataCovid <- extract_covid19_data("New Zealand","global","Desktop","covid19JHU")
#' @examples dataNZ <- mkEpiTable(dataCovid,"New Zealand")
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand")
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7)
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(confirmed=1.2))
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(deaths=1.1))
#' @examples mkEpiCurves(dataNZ,plot.title="New Zealand",project=7,rates=list(confirmed=1.2,deaths=1.1))
#' @seealso \code{\link{load_JH_db}}
#' @seealso \code{\link{extract_covid19_data}}
#' @seealso \code{\link{mkEpiTable}}
#' @export
mkEpiCurves <- function(data,X=NULL,project=NULL,rates=NULL,plot.curves=TRUE,plot.title=NULL,plot.as.panel=TRUE,country=NULL)
{
  #--------------------#
  # first preparations #
  #--------------------#
  if(any(names(data) == "t")){
    plot.curves <- FALSE
  }
  # cut data to contain only records with confirmed > 0
  data <- data[min(which(data$confirmed >= 1)):nrow(data),]
  # calculate rates
  rates.obs <- data.frame(date=data$date,confirmed=rep(0,nrow(data)),deaths=rep(0,nrow(data)),recovered=rep(0,nrow(data)))
  tmp <- c(0,data$confirmed[-1]/data$confirmed[-nrow(data)])
  rates.obs$confirmed <- c(rep(0,min(which(data$confirmed > 0))),tmp[(min(which(data$confirmed > 0))+1):nrow(data)])
  tmp <- c(0,data$deaths[-1]/data$deaths[-nrow(data)])
  rates.obs$deaths <- c(rep(0,min(which(data$deaths > 0))),tmp[(min(which(data$deaths > 0))+1):nrow(data)])
  if(!any(is.na(data[,"recovered"]))){
    tmp <- c(0,data$recovered[-1]/data$recovered[-nrow(data)])
    rates.obs$recovered <- c(rep(0,min(which(data$recovered > 0))),tmp[(min(which(data$recovered > 0))+1):nrow(data)])
  }
  #----------------#
  # add projection #
  #----------------#
  if(!is.null(project)){
    if(is.null(rates)){
      rates <- list(confirmed=mean(rev(rates.obs$confirmed)[1:5]),deaths=mean(rev(rates.obs$deaths)[1:5]))
    } else{
      if(!any(names(rates) == "confirmed")){
        rates$confirmed=max(c(1,mean(rev(rates.obs$confirmed)[1:5])))
      }
      if(!any(names(rates) == "deaths")){
        rates$deaths=max(c(1,mean(rev(rates.obs$deaths)[1:5])))
      }
    }
    data_project <- data.frame(date=data$date[nrow(data)]+1:project,confirmed=rep(NA,project),deaths=rep(NA,project),recovered=rep(max(data$recovered),project))
    data_project$confirmed <- round(data$confirmed[nrow(data)]*rates$confirmed^(1:project))
    data_project$deaths <- round(data$deaths[nrow(data)]*rates$deaths^(1:project))
    if(!any(is.na(data[,"recovered"]))){
      data_project$active <- data_project$confirmed - data_project$deaths - data_project$recovered
    } else data_project$active <- rep(NA,project)
    data <- rbind(data,data_project)
  }
  #--------------------------------------------------------#
  # functions to optmize model and estimate the parameters #
  #--------------------------------------------------------#
  yhat <- function(par,t,X){
    if(is.null(X)){
      yh <- par[1]/(1+exp(-par[2]-par[3]*t))
    } else{
      if(class(X) == "matrix"){
        yh <- par[1]/(1+exp(-par[2]-par[3]*t+as.numeric(X%*%par[4:length(par)])))
      } else yh <- par[1]/(1+exp(-par[2]-par[3]*t+X*par[4]))
    }
    return(yh)
  }
  SSE <- function(par,y,t,X)
  {
    e <- y-yhat(par,t,X)
    return(sum(e^2))
  }
  SSE.grad <- function(par,y,t,X)
  {
    e <- y-yhat(par,t,X)
    da <- sum(-2*e*yhat(c(1,par[2:length(par)]),t,X))
    db <- sum(-2*e*yhat(par,t,X)*(1-yhat(c(1,par[2:length(par)]),t,X)))
    dc <- sum(-2*e*t*yhat(par,t,X)*(1-yhat(c(1,par[2:length(par)]),t,X)))
    dSSE <- c(c(da,db,dc))
    if(!is.null(X)){
      if(class(X) == "matrix"){
        for(j in 1:ncol(X)){
          dalpha <- sum(2*e*X[,j]*yhat(par,t,X)*(1-yhat(c(1,par[2:length(par)]),t,X)))
          dSSE <- c(dSSE,dalpha)
        }
      } else{
        dalpha <- sum(2*e*X*yhat(par,t,X)*(1-yhat(c(1,par[2:length(par)]),t,X)))
        dSSE <- c(dSSE,dalpha)
      }
    }
    return(dSSE)
  }
  #-----------------------#
  # model confirmed cases #
  #-----------------------#
  y <- data$confirmed
  if(any(names(data) == "t")){
    t <- data$t
  } else{
    tmp <- data$date
    t <- cumsum(c(1,as.numeric(tmp[-1]-tmp[-length(tmp)])))
    rm(tmp)
  }
  SSEy <- function(p){
    return(SSE(p,y,t,X$confirmed))
  }
  SSEy.grad <- function(p){
    return(SSE.grad(p,y,t,X$confirmed))
  }
  ui <- cbind(c(1,0,0,0),c(0,-1,0,0),c(0,0,1,-1))
  ci <- c(max(y),0,0,-1)
  par0 <- c(max(y)+1,-1,0.5)
  if(!is.null(X$confirmed)){
    ui <- cbind(ui,matrix(0,4,ifelse(class(X$confirmed) == "matrix",ncol(X$confirmed),1)))
    par0 <- c(par0,rep(0,ifelse(class(X$confirmed) == "matrix",ncol(X$confirmed),1)))
  }
  aux <- constrOptim(par0,SSEy,SSEy.grad,ui,ci)$par
  aux[2] <- -aux[2]/aux[3]
  aux[3] <- 1/aux[3]
  npar <- 0
  if(!is.null(X)){
    for(i in 1:length(X)){
      npar <- max(npar,ifelse(class(X[[i]]) == "matrix",ncol(X),1))
    }
  }
  parLogEpi <- matrix(NA,3,3+npar)
  parLogEpi[1,1:length(aux)] <- aux
  #--------------#
  # model deaths #
  #--------------#
  if(any(data$deaths > 0)){
    y <- data$deaths[data$deaths > 0]
    if(any(names(data) == "t")){
      t <- data$t
    } else{
      tmp <- data$date[data$deaths > 0]
      t <- cumsum(c(1,as.numeric(tmp[-1]-tmp[-length(tmp)])))
      rm(tmp)
    }
    if(!is.null(X$deaths)){
      if(class(X$deaths) == "matrix"){
        X$deaths <- X$deaths[data$deaths > 0,]
      } else X$deaths <- X$deaths[data$deaths > 0]
    }
    SSEy <- function(p){
      return(SSE(p,y,t,X$deaths))
    }
    SSEy.grad <- function(p){
      return(SSE.grad(p,y,t,X$deaths))
    }
    ui=cbind(c(-1,1,0,0,0),c(0,0,-1,0,0),c(0,0,0,1,-1))
    ci <- c(-round(parLogEpi[1]),max(y),0,0,-1)
    par0 <- c(max(y)+1,-1,0.5)
    if(!is.null(X$deaths)){
      ui <- cbind(ui,matrix(0,5,ifelse(class(X$deaths) == "matrix",ncol(X$deaths),1)))
      par0 <- c(par0,rep(0,ifelse(class(X$confirmed) == "matrix",ncol(X$confirmed),1)))
    }
    aux <- constrOptim(par0,SSEy,SSEy.grad,ui,ci)$par
    aux[2] <- -aux[2]/aux[3] + ifelse(any(names(data) == "t"),0,which(data$deaths > 0)[1] - 1)
    aux[3] <- 1/aux[3]
    parLogEpi[2,1:length(aux)] <- aux
  } else stop("At least 'confirmed' and 'deaths' must contain values.")
  #-----------------#
  # model recovered #
  #-----------------#
  if(!any(is.na(data$recovered))){
    y <- data$recovered[data$recovered > 0]
    if(any(names(data) == "t")){
      t <- data$t
    } else{
      tmp <- data$date[data$recovered > 0]
      t <- cumsum(c(1,as.numeric(tmp[-1]-tmp[-length(tmp)])))
      rm(tmp)
    }
    if(!is.null(X$recovered)){
      if(class(X$recovered) == "matrix"){
        X$recovered <- X$recovered[data$recovered > 0,]
      } else X$recovered <- X$recovered[data$recovered > 0]
    }
    SSEy <- function(p){
      return(SSE(c(parLogEpi[1]-parLogEpi[2],p),y,t,X$recovered))
    }
    SSEy.grad <- function(p){
      return(SSE.grad(c(parLogEpi[1]-parLogEpi[2],p),y,t,X$recovered)[-1])
    }
    ui=cbind(c(-1,0,0),c(0,1,-1))
    ci <- c(0,0,-1)
    par0 <- c(-1,0.5)
    if(!is.null(X$recovered)){
      ui <- cbind(ui,matrix(0,5,ifelse(class(X$recovered) == "matrix",ncol(X$recovered),1)))
      par0 <- c(par0,rep(0,ifelse(class(X$confirmed) == "matrix",ncol(X$confirmed),1)))
    }
    aux <- c(parLogEpi[1]-parLogEpi[2],constrOptim(par0,SSEy,SSEy.grad,ui,ci)$par)
    aux[2] <- -aux[2]/aux[3] + ifelse(any(names(data) == "t"),0,which(data$recovered > 0)[1] - 1)
    aux[3] <- 1/aux[3]
    parLogEpi[3,1:length(aux)] <- aux
  } else{
    aux <- c(parLogEpi[1,1]-parLogEpi[2,1],parLogEpi[1,2]+26,(parLogEpi[1,2]+27)/log(parLogEpi[1,1]-parLogEpi[2,1]-1))
    parLogEpi[3,1:3] <- aux
  }
  #-------------------------------------#
  # touch up object with the parameters #
  #-------------------------------------#
  rownames(parLogEpi) <- c("confirmed","deaths","recovered")
  tmp <- c("a","b","c")
  if(ncol(parLogEpi) > 3){
    tmp <- c(tmp,paste("alpha",1:(ncol(parLogEpi)-3),sep=""))
  }
  colnames(parLogEpi) <- tmp
  #---------------------------------#
  # get fitted values and residuals #
  #---------------------------------#
  if(any(names(data) == "t")){
    t <- data$t
  } else{
    tmp <- data$date
    t <- cumsum(c(1,as.numeric(tmp[-1]-tmp[-length(tmp)])))
    rm(tmp)
  }
  yfit <- data.frame(date=data$date,confirmed=round(logCurve(parLogEpi[1,],t,X$confirmed)),deaths=round(logCurve(parLogEpi[2,],t,X$deaths)))
  yres <- data.frame(date=data$date,confirmed=(data$confirmed-yfit$confirmed),deaths=(data$deaths-yfit$deaths))
  if(!any(is.na(data$recovered))){
    yfit$recovered <- round(logCurve(parLogEpi[3,],t,X$recovered))
    yfit$active <- yfit$confirmed - yfit$deaths - yfit$recovered
    yres$recovered <- data$recovered - yfit$recovered
    yres$active <- data$active - yfit$active
  }
  #-------------------------#
  # create plot if required #
  #-------------------------#
  if(plot.curves){
    if(!is.null(project)){
      data <- data[1:(nrow(data)-project),]
    }
    if(plot.as.panel){
      par(mfrow=c(1,2))
    }
    td <- cumsum(c(1,as.numeric(data$date[-1]-data$date[-length(data$date)])))
    t <- 1:round(2*max(parLogEpi[,"b"]))
    yfit <- data.frame(date=data$date[1]+t-1,confirmed=rep(NA,length(t)),deaths=rep(NA,length(t)),recovered=rep(NA,length(t)),active=rep(NA,length(t)))
    for(k in c("confirmed","deaths","recovered")){
      data[,k] <- data[,k]/1000
      if(!any(is.na(parLogEpi[k,1:3]))){
        yfit[,k] <- round(logCurve(parLogEpi[k,],t,X[[k]]))/1000
      }
    }
    data$active <- data$active/1000
    if(!any(is.na(yfit$recovered))){
      yfit$active <- yfit$confirmed-yfit$deaths-yfit$recovered
    }
    keyd <- rep(NA,4)
    names(keyd) <- c("start_critical","inflection","most_critical","end_critical")
    keyd["inflection"] <- round(parLogEpi[1,"b"])
    keyd["start_critical"] <- ifelse(keyd["inflection"] <= 28,1,keyd["inflection"]-28)
    keyd["most_critical"] <- ifelse(any(is.na(yfit$active)),keyd["inflection"]+14,which(yfit$active == max(yfit$active)))
    keyd["end_critical"] <- keyd["most_critical"] + 28
    par(mar=c(2,4.5,1,1))
    colfit <- c(4,2,3)
    pchfit <- c(19,4,5)
    names(colfit) <- c("confirmed","deaths","recovered")
    names(pchfit) <- c("confirmed","deaths","recovered")
    plot(NA,xlim=keyd[paste0(c("start","end"),"_critical")]+c(-7,7),ylim=c(0,max(yfit$confirmed)),xlab="",ylab="cumulative (x 1,000)",axes=FALSE)
    abline(h=0)
    tmp <- yfit$date[keyd]
    tmp <- paste(day(tmp),substr(month.name[month(tmp)],1,3),sep="/")
    axis(1,at=keyd,labels=tmp,pos=0,cex.axis=0.9)
    axis(2)
    mtext(c("inflection","most critical"),side=1,line=1,at=keyd[c("inflection","most_critical")],cex=0.75)
    lines(rep(keyd["inflection"],2),c(0,yfit$confirmed[keyd["inflection"]]),lty=2)
    lines(rep(keyd["most_critical"],2),c(0,yfit$confirmed[keyd["most_critical"]]),lty=2)
    for(k in c("recovered","deaths","confirmed")){
      lines(t,yfit[,k],col=colfit[k])
      points(td,data[,k],col=colfit[k],pch=pchfit[k],cex=0.4)
    }
    yfitSAVE <- yfit
    yfit <- yfit[1:max(keyd)+14,]
    par(mar=c(2,4.5,0,1),new=TRUE)
    plot(NA,xlim=c(0,1),ylim=c(0,1),xlab="",ylab="",axes=FALSE)
    text(-0.025,0.965,pos=4,font=2,labels=paste0(ifelse(is.null(plot.title),"",paste0(plot.title,": ")),paste(day(yfit$date[nrow(yfit)]),substr(month.name[month(yfit$date[nrow(yfit)])],1,3),year(yfit$date[nrow(yfit)]),sep="/")))
    text(rep(-0.025,4),c(0.9,0.84,0.78,0.72),pos=4,labels=c(paste(c("confirmed:","deaths:"),format(yfit[nrow(yfit),2:3]*1000,big.mark=",")),paste0("death rate: ",round(100*yfit[nrow(yfit),"deaths"]/yfit[nrow(yfit),"confirmed"],2),"%"),paste("max. active:",format(round(max(yfit$active)*1000),big.mark=","))),cex=0.9)
    yfit <- yfitSAVE
    par(mar=c(2,3.5,1,1))
    plot(NA,xlim=c(1,max(t)),ylim=c(0,max(c(data$active,yfit$active),na.rm=TRUE)),xlab="",ylab="",axes=FALSE)
    mtext("active cases (x 1,000)",side=2,line=2)
    abline(h=0)
    abline(v=0)
    tmp <- c(round(quantile(t,0.25)),keyd["most_critical"],round(quantile(t,0.75)))
    aux <- paste(day(yfit$date[tmp]),substr(month.name[month(yfit$date[tmp])],1,3),sep="/")
    axis(1,at=tmp,labels=aux,pos=0,cex=0.9)
    axis(2,pos=0)
    arrows(td,rep(0,nrow(data)),td,data$active,code=0,col=8)
    lines(t,yfit$active,col=4)
    lines(t,0.2*yfit$active,col=2,lty=2)
    lines(t,0.05*yfit$active,col=2)
    if(!is.null(country)){
      if(country %in% CountryData$country){
        hospital_beds <- 0.05*CountryData[CountryData$country == country,3]*CountryData[CountryData$country == country,"pop2018"]/1000000
        abline(h=hospital_beds)
        text(max(t),hospital_beds+0.06*round(max(c(data$active,yfit$active),na.rm=TRUE)),labels="health system",pos=2,offset=0,cex=0.8)
        text(max(t),hospital_beds+0.03*round(max(c(data$active,yfit$active),na.rm=TRUE)),labels="capacity",pos=2,offset=0,cex=0.8)
      }
    }
    legend("topright",bty="n",lty=c(1,2,1,1),col=c(4,2,2,8),legend=c("active cases","need some care","need intensive care","observed data"))
    yfit[,-1] <- 1000*yfit[,-1]
  }
  #----------------#
  # data to return #
  #----------------#
  if(is.null(project)){
    if(plot.curves){
      fitdata <- list(par=parLogEpi,key_dates=yfit$date[keyd],fit=yfit,res=yres,rates=rates.obs)
    } else fitdata <- list(par=parLogEpi,fit=yfit,res=yres,rates=rates.obs)
  } else {
    if(plot.curves){
      fitdata <- list(par=parLogEpi,key_dates=yfit$date[keyd],fit=yfit,res=yres,rates=rates.obs,projection=data_project,rates_proj=rates)
    } else fitdata <- list(par=parLogEpi,fit=yfit,res=yres,rates=rates.obs,projection=data_project,rates_proj=rates)
  }
  return(fitdata)
}

#' Create comparative epidemic plots
#'
#' This function will make comparatice epidemic plots.
#'
#' @param location The name of the locations of interest.
#' @param data The data base where each location is at. Either "global" or "US".
#' @param folder The folder in which the downloaded data was saved with load_JH_db().
#' @param filename The standard filename with which the data was saved with load_JH_db().
#' @param cases.count The minimum number of cases from which the data should be considered. Default is 100.
#' @param plot.as.panel Logical, defining if plots should be plotted as panel in a single figure, or as individual figures. Default is \code{plot.as.panel=TRUE}.
#' @return A set of three comparative epidemic plots.
#' @examples load_JH_db("Desktop","covid19JHU")
#' @examples mkEpiComparePlot(location=c("Italy","Spain","United Kingdom","France"),data=rep("global",4),"Desktop","covid19JHU")
#' @examples mkEpiComparePlot(location=c("New York","New Jersey","California"),data=rep("US",3),"Desktop","covid19JHU")
#' @export
mkEpiComparePlot <- function(location,data,folder,filename,cases.count=100,plot.as.panel=TRUE)
{
  tmp.folder <- folder
  tmp.filename <- filename
  place <- location
  place.data <- data
  ncases <- cases.count

  tbMulti <- list(0)
  nmMulti <- character(0)
  plMulti <- character(0)
  i <- 1
  for(k in 1:length(place)){
    if(place.data[k] == "global"){
      if(place[k] %in% CountryData$country){
        if(!is.na(CountryData$pop2018[CountryData$country == place[k]])){
          tmp <- mkEpiTable(extract_covid19_data(location=place[k],data=place.data[k],tmp.folder,tmp.filename))
          if(nrow(tmp) > 0){
            if(tmp$confirmed[nrow(tmp)] > ncases){
              tbMulti[[i]] <- tmp
              tbMulti[[i]] <- tbMulti[[i]][tbMulti[[i]]$confirmed >= ncases,]
              tbMulti[[i]][,-1] <- 1000*tbMulti[[i]][,-1]/CountryData$pop2018[CountryData$country == place[k]]
              t <- cumsum(c(1,tbMulti[[i]]$date[-1]-tbMulti[[i]]$date[-nrow(tbMulti[[i]])]))
              tbMulti[[i]] <- data.frame(date=tbMulti[[i]][,1],t=t,tbMulti[[i]][,-c(1,4,5)],death_rate=tbMulti[[i]][,"deaths"]/tbMulti[[i]][,"confirmed"],r_confirmed=c(0,tbMulti[[i]]$confirmed[-1]/tbMulti[[i]]$confirmed[-nrow(tbMulti[[i]])]),r_deaths=c(0,tbMulti[[i]]$deaths[-1]/tbMulti[[i]]$deaths[-nrow(tbMulti[[i]])]))
              tbMulti[[i]]$r_deaths[is.nan(tbMulti[[i]]$r_deaths)] <- 0
              tbMulti[[i]]$r_deaths[tbMulti[[i]]$r_deaths == Inf] <- 1
              nmMulti <- c(nmMulti,place[k])
              plMulti <- c(plMulti,place.data[k])
              i <- i + 1
            }
          }
        }
      }
    } else if(place.data[k] == "US"){
      if(place[k] %in% USstatesData$state){
        if(!is.na(USstatesData$pop2019[USstatesData$state == place[k]])){
          tmp <- mkEpiTable(extract_covid19_data(location=place[k],data=place.data[k],tmp.folder,tmp.filename))
          if(nrow(tmp) > 0){
            if(tmp$confirmed[nrow(tmp)] > ncases){
              tbMulti[[i]] <- tmp
              tbMulti[[i]] <- tbMulti[[i]][tbMulti[[i]]$confirmed >= ncases,]
              tbMulti[[i]][,-1] <- 1000*tbMulti[[i]][,-1]/USstatesData$pop2019[USstatesData$state == place[k]]
              t <- cumsum(c(1,tbMulti[[i]]$date[-1]-tbMulti[[i]]$date[-nrow(tbMulti[[i]])]))
              tbMulti[[i]] <- data.frame(date=tbMulti[[i]][,1],t=t,tbMulti[[i]][,-c(1,4,5)],death_rate=tbMulti[[i]][,"deaths"]/tbMulti[[i]][,"confirmed"],r_confirmed=c(0,tbMulti[[i]]$confirmed[-1]/tbMulti[[i]]$confirmed[-nrow(tbMulti[[i]])]),r_deaths=c(0,tbMulti[[i]]$deaths[-1]/tbMulti[[i]]$deaths[-nrow(tbMulti[[i]])]))
              tbMulti[[i]]$r_deaths[is.nan(tbMulti[[i]]$r_deaths)] <-
                tbMulti[[i]]$r_deaths[tbMulti[[i]]$r_deaths == Inf] <- 1
              nmMulti <- c(nmMulti,place[k])
              plMulti <- c(plMulti,place.data[k])
              i <- i + 1
            }
          }
        }
      }
    }
  }
  names(tbMulti) <- nmMulti

  tmp <- apply(matrix(unlist(lapply(lapply(tbMulti,subset,select=2:7),apply,2,max)),length(tbMulti),byrow=TRUE),2,max)
  names(tmp) <- names(tbMulti[[1]])[-1]
  tmp

  col_place <- hcl.colors(length(place),"Dark 3")
  names(col_place) <- names(tbMulti)
  if(plot.as.panel){
    par(mfrow=c(1,3))
  }
  par(mar=c(4.25,4.5,1.25,1))
  plot(NA,xlim=c(1,1.1*tmp["t"]),ylim=c(0,tmp["confirmed"]),xlab="days",ylab="confirmed cases per 1,000 inhabitants")
  for(k in names(tbMulti)){
    lines(tbMulti[[k]]$t,tbMulti[[k]]$confirmed,col=col_place[k])
    text(tbMulti[[k]]$t[nrow(tbMulti[[k]])],tbMulti[[k]]$confirmed[nrow(tbMulti[[k]])],labels=k,col=col_place[k],pos=4,offset=0.25,cex=0.75)
  }
  plot(NA,xlim=c(1,1.1*tmp["t"]),ylim=c(0,tmp["deaths"]),xlab="days",ylab="deaths per 1,000 inhabitants")
  for(k in names(tbMulti)){
    lines(tbMulti[[k]]$t,tbMulti[[k]]$deaths,col=col_place[k])
    text(tbMulti[[k]]$t[nrow(tbMulti[[k]])],tbMulti[[k]]$deaths[nrow(tbMulti[[k]])],labels=k,col=col_place[k],pos=4,offset=0.25,cex=0.75)
  }
  plot(NA,xlim=c(1,1.1*tmp["t"]),ylim=c(0,100*tmp["death_rate"]),xlab="days",ylab="death rate (%)")
  for(k in names(tbMulti)){
    lines(tbMulti[[k]]$t,100*tbMulti[[k]]$death_rate,col=col_place[k])
    text(tbMulti[[k]]$t[nrow(tbMulti[[k]])],100*tbMulti[[k]]$death_rate[nrow(tbMulti[[k]])],labels=k,col=col_place[k],pos=4,offset=0.25,cex=0.75)
  }
}
